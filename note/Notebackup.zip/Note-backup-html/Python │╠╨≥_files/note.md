Locust_jump.py: 蚂蚱跳
Spiral.py:螺旋
English_learn.py:文件读写的问题
模拟QQ登陆的没做
Patch_optimal.py:cost有问题，未实现功能
Sprial_number.py:没看懂，还得好好看
date_file.py:存在问题